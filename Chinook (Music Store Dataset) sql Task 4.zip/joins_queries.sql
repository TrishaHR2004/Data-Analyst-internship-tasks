-- ARTIST
CREATE TABLE artist (
    artistid INT PRIMARY KEY,
    name VARCHAR(200)
);

drop table album cascade;
-- ALBUM
CREATE TABLE album (
    albumid INT PRIMARY KEY,
    title VARCHAR(200),
    artistid INT REFERENCES artist(artistid)
);

select * from album;

-- GENRE
CREATE TABLE genre (
    genreid INT PRIMARY KEY,
    name VARCHAR(100)
);

-- MEDIATYPE
CREATE TABLE mediatype (
    mediatypeid INT PRIMARY KEY,
    name VARCHAR(100)
);

-- TRACK (PRODUCTS)
CREATE TABLE track (
    trackid INT PRIMARY KEY,
    name VARCHAR(200),
    albumid INT REFERENCES album(albumid),
    mediatypeid INT REFERENCES mediatype(mediatypeid),
    genreid INT REFERENCES genre(genreid),
    composer VARCHAR(200),
    milliseconds INT,
    bytes INT,
    unitprice NUMERIC(10,2)
);

-- CUSTOMER
CREATE TABLE customer (
    customerid INT PRIMARY KEY,
    firstname VARCHAR(100),
    lastname VARCHAR(100),
    company VARCHAR(200),
    address VARCHAR(200),
    city VARCHAR(100),
    state VARCHAR(100),
    country VARCHAR(100),
    postalcode VARCHAR(20),
    phone VARCHAR(50),
    fax VARCHAR(50),
    email VARCHAR(100),
    supportrepid INT
);

-- EMPLOYEE
CREATE TABLE employee (
    employeeid INT PRIMARY KEY,
    lastname VARCHAR(100),
    firstname VARCHAR(100),
    title VARCHAR(100),
    reportsto INT,
    birthdate DATE,
    hiredate DATE,
    address VARCHAR(200),
    city VARCHAR(100),
    state VARCHAR(100),
    country VARCHAR(100),
    postalcode VARCHAR(20),
    phone VARCHAR(50),
    fax VARCHAR(50),
    email VARCHAR(100)
);

-- INVOICE (ORDERS)
CREATE TABLE invoice (
    invoiceid INT PRIMARY KEY,
    customerid INT REFERENCES customer(customerid),
    invoicedate TIMESTAMP,
    billingaddress VARCHAR(200),
    billingcity VARCHAR(100),
    billingstate VARCHAR(100),
    billingcountry VARCHAR(100),
    billingpostalcode VARCHAR(20),
    total NUMERIC(10,2)
);

-- INVOICELINE (ORDER ITEMS)
CREATE TABLE invoiceline (
    invoicelineid INT PRIMARY KEY,
    invoiceid INT REFERENCES invoice(invoiceid),
    trackid INT REFERENCES track(trackid),
    unitprice NUMERIC(10,2),
    quantity INT
);

-- PLAYLIST
CREATE TABLE playlist (
    playlistid INT PRIMARY KEY,
    name VARCHAR(200)
);

-- PLAYLIST TRACK (BRIDGE TABLE)
CREATE TABLE playlisttrack (
    playlistid INT REFERENCES playlist(playlistid),
    trackid INT REFERENCES track(trackid),
    PRIMARY KEY (playlistid, trackid)
);



--Verify ALL Tables Have Data (One Clean Result)--

SELECT 'artist' AS table_name, COUNT(*) AS total_rows FROM artist
UNION ALL
SELECT 'album', COUNT(*) FROM album
UNION ALL
SELECT 'genre', COUNT(*) FROM genre
UNION ALL
SELECT 'mediatype', COUNT(*) FROM mediatype
UNION ALL
SELECT 'track', COUNT(*) FROM track
UNION ALL
SELECT 'customer', COUNT(*) FROM customer
UNION ALL
SELECT 'employee', COUNT(*) FROM employee
UNION ALL
SELECT 'invoice', COUNT(*) FROM invoice
UNION ALL
SELECT 'invoiceline', COUNT(*) FROM invoiceline
UNION ALL
SELECT 'playlist', COUNT(*) FROM playlist
UNION ALL
SELECT 'playlisttrack', COUNT(*) FROM playlisttrack;




SELECT * FROM artist LIMIT 5;
SELECT * FROM album LIMIT 5;
SELECT * FROM genre LIMIT 5;
SELECT * FROM mediatype LIMIT 5;
SELECT * FROM track LIMIT 5;
SELECT * FROM customer LIMIT 5;
SELECT * FROM employee LIMIT 5;
SELECT * FROM invoice LIMIT 5;
SELECT * FROM invoiceline LIMIT 5;
SELECT * FROM playlist LIMIT 5;
SELECT * FROM playlisttrack LIMIT 5;


-- Basic INNER JOIN (Clean & Professional)--
SELECT 
    c.customerid,
    c.firstname,
    c.lastname,
    c.country,
    i.invoiceid,
    i.invoicedate,
    i.total
FROM customer c
INNER JOIN invoice i
    ON c.customerid = i.customerid
ORDER BY i.invoicedate DESC;


--Validate Join (Order Count Check)
SELECT COUNT(*) AS total_orders
FROM invoice;

SELECT COUNT(*) AS joined_orders
FROM customer c
INNER JOIN invoice i
    ON c.customerid = i.customerid;



--Business View — High-Value Customers
SELECT 
    c.customerid,
    c.firstname,
    c.lastname,
    SUM(i.total) AS lifetime_value
FROM customer c
INNER JOIN invoice i
    ON c.customerid = i.customerid
GROUP BY c.customerid, c.firstname, c.lastname
ORDER BY lifetime_value DESC
LIMIT 10;



--“Which customers never placed any orders?”
--These are high-value targets for campaigns, discounts, and onboarding.	

--Find Customers with NO Orders
SELECT 
    c.customerid,
    c.firstname,
    c.lastname,
    c.country,
    c.email
FROM customer c
LEFT JOIN invoice i
    ON c.customerid = i.customerid
WHERE i.invoiceid IS NULL;


--Count Inactive Customers

SELECT 
    COUNT(*) AS customers_with_no_orders
FROM customer c
LEFT JOIN invoice i
    ON c.customerid = i.customerid
WHERE i.invoiceid IS NULL;

--I use a LEFT JOIN and filter on NULL values from the right table to identify records that don’t have matching rows, such as customers with no orders.





--Which tracks (products) generate the highest revenue?
--Revenue Per Product (Clean & Professional)


SELECT 
    t.trackid,
    t.name AS product_name,
    SUM(il.unitprice * il.quantity) AS total_revenue
FROM track t
INNER JOIN invoiceline il
    ON t.trackid = il.trackid
GROUP BY t.trackid, t.name
ORDER BY total_revenue DESC
LIMIT 10;


--Add Category (Genre) for Business Context

SELECT 
    g.name AS category,
    t.name AS product_name,
    SUM(il.unitprice * il.quantity) AS total_revenue
FROM track t
INNER JOIN invoiceline il
    ON t.trackid = il.trackid
INNER JOIN genre g
    ON t.genreid = g.genreid
GROUP BY g.name, t.name
ORDER BY total_revenue DESC
LIMIT 10;

--This query helps identify high-performing products and their categories, which supports pricing, promotion, and inventory decisions.

--Which categories (genres) contribute the most to total revenue?
--This helps management decide where to invest marketing and product strategy.

--Total Revenue by Category
SELECT 
    g.name AS category,
    SUM(il.unitprice * il.quantity) AS total_revenue
FROM genre g
INNER JOIN track t
    ON g.genreid = t.genreid
INNER JOIN invoiceline il
    ON t.trackid = il.trackid
GROUP BY g.name
ORDER BY total_revenue DESC;

--Revenue Percentage Contribution (Executive View)

SELECT 
    g.name AS category,
    ROUND(
        SUM(il.unitprice * il.quantity) * 100.0 /
        SUM(SUM(il.unitprice * il.quantity)) OVER (),
        2
    ) AS revenue_percentage
FROM genre g
INNER JOIN track t
    ON g.genreid = t.genreid
INNER JOIN invoiceline il
    ON t.trackid = il.trackid
GROUP BY g.name
ORDER BY revenue_percentage DESC;



--“How much did we sell in a specific country and time period?”

--Revenue by Country

SELECT 
    c.country,
    SUM(il.unitprice * il.quantity) AS total_revenue
FROM customer c
INNER JOIN invoice i
    ON c.customerid = i.customerid
INNER JOIN invoiceline il
    ON i.invoiceid = il.invoiceid
WHERE c.country = 'USA'
GROUP BY c.country;


--Sales Between Date Range

SELECT 
    DATE(i.invoicedate) AS sale_date,
    SUM(il.unitprice * il.quantity) AS daily_revenue
FROM invoice i
INNER JOIN invoiceline il
    ON i.invoiceid = il.invoiceid
WHERE i.invoicedate BETWEEN '2012-01-01' AND '2013-12-31'
GROUP BY DATE(i.invoicedate)
ORDER BY sale_date;


--Country + Category Revenue

SELECT 
    c.country,
    g.name AS category,
    SUM(il.unitprice * il.quantity) AS total_revenue
FROM customer c
INNER JOIN invoice i
    ON c.customerid = i.customerid
INNER JOIN invoiceline il
    ON i.invoiceid = il.invoiceid
INNER JOIN track t
    ON il.trackid = t.trackid
INNER JOIN genre g
    ON t.genreid = g.genreid
GROUP BY c.country, g.name
ORDER BY total_revenue DESC;

--I apply WHERE filters on joined tables to answer business-specific questions like region-wise and time-based revenue trends.


-- Final Joined Output (For Export) — it combines customer, orders, product, and category:

SELECT 
    c.customerid,
    c.firstname,
    c.lastname,
    c.country,
    i.invoiceid,
    DATE(i.invoicedate) AS invoice_date,
    g.name AS category,
    t.name AS product_name,
    il.quantity,
    il.unitprice,
    (il.unitprice * il.quantity) AS revenue
FROM customer c
INNER JOIN invoice i
    ON c.customerid = i.customerid
INNER JOIN invoiceline il
    ON i.invoiceid = il.invoiceid
INNER JOIN track t
    ON il.trackid = t.trackid
INNER JOIN genre g
    ON t.genreid = g.genreid
ORDER BY revenue DESC;



---insights.txt
--1. The top 3 products contribute a significant portion of total revenue, indicating strong demand concentration.
--2. Certain genres (categories) consistently outperform others, making them ideal targets for marketing and promotions.
--3. A small group of high-value customers generates a large share of sales, suggesting opportunities for loyalty and retention programs.
