DROP TABLE IF EXISTS superstore_sales;

CREATE TABLE superstore_sales (
    ship_mode VARCHAR(50),
    segment VARCHAR(50),
    country VARCHAR(50),
    city VARCHAR(50),
    state VARCHAR(50),
    postal_code VARCHAR(20),
    region VARCHAR(50),
    category VARCHAR(50),
    sub_category VARCHAR(50),
    sales NUMERIC(10,2),
    quantity INT,
    discount NUMERIC(4,2),
    profit NUMERIC(10,2)
);


Select * from superstore_sales;


SELECT *
FROM superstore_sales
LIMIT 10;


SELECT *
FROM superstore_sales
WHERE category = 'Technology';


SELECT *
FROM superstore_sales
WHERE region = 'West';

SELECT *
FROM superstore_sales
ORDER BY sales DESC
LIMIT 10;


SELECT *
FROM superstore_sales
WHERE category = 'Technology'
ORDER BY profit DESC
LIMIT 10;


SELECT *
FROM superstore_sales
WHERE city LIKE 'New%';



SELECT 
    category,
    SUM(sales) AS total_sales
FROM superstore_sales
GROUP BY category
ORDER BY total_sales DESC;


SELECT 
    region,
    AVG(profit) AS avg_profit
FROM superstore_sales
GROUP BY region
ORDER BY avg_profit DESC;


SELECT 
    segment,
    COUNT(*) AS total_orders
FROM superstore_sales
GROUP BY segment
ORDER BY total_orders DESC;


SELECT 
    category,
    region,
    SUM(sales) AS total_sales,
    SUM(profit) AS total_profit
FROM superstore_sales
GROUP BY category, region
ORDER BY total_sales DESC;


SELECT 
    sub_category,
    SUM(sales) AS total_sales
FROM superstore_sales
GROUP BY sub_category
ORDER BY total_sales DESC
LIMIT 5;



SELECT 
    category,
    SUM(sales) AS total_sales
FROM superstore_sales
GROUP BY category
HAVING SUM(sales) > 100000
ORDER BY total_sales DESC;


SELECT 
    region,
    SUM(profit) AS total_profit
FROM superstore_sales
GROUP BY region
HAVING SUM(profit) > 50000
ORDER BY total_profit DESC;


SELECT 
    sub_category,
    SUM(sales) AS total_sales
FROM superstore_sales
GROUP BY sub_category
HAVING SUM(sales) BETWEEN 50000 AND 200000
ORDER BY total_sales DESC;


SELECT 
    category,
    AVG(discount) AS avg_discount
FROM superstore_sales
GROUP BY category
HAVING AVG(discount) > 0.2
ORDER BY avg_discount DESC;


SELECT 
    region,
    COUNT(*) AS total_orders
FROM superstore_sales
GROUP BY region
HAVING COUNT(*) > 500
ORDER BY total_orders DESC;





SELECT 
    category,
    region,
    SUM(sales) AS total_sales,
    SUM(profit) AS total_profit
FROM superstore_sales
GROUP BY category, region
ORDER BY total_sales DESC;

